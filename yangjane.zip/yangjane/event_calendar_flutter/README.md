# event_calendar_flutter
 A Flutter project for managing and displaying event calendars.
